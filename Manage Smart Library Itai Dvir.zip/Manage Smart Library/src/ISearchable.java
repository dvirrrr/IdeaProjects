public interface ISearchable {
    boolean matches(String keyword);
}