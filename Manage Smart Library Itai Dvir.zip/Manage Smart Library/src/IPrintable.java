public interface IPrintable {
    void printDetails();
}