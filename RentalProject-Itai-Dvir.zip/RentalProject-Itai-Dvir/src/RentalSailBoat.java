public class RentalSailBoat extends RentalBoat {
    public RentalSailBoat(int rentalID, String currentRental, int numOfPassengers) {
        super(rentalID, currentRental, numOfPassengers);
    }
}
