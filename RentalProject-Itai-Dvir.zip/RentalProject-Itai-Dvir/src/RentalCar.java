public class RentalCar extends RentalVehicle {
    private carType style;
    private int weight;

    public RentalCar(int rentalID, String currentRental, int numOfPassengers) {
        super(rentalID, currentRental, numOfPassengers);
    }
}
