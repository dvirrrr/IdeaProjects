public class RentalBoat extends RentalVehicle {
    public RentalBoat(int rentalID, String currentRental, int numOfPassengers) {
        super(rentalID, currentRental, numOfPassengers);
    }
}
