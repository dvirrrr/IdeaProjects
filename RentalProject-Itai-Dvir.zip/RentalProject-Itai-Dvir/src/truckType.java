public enum truckType {
    shortBed,
    longBed
}
