public class RentalTruck extends RentalVehicle {
    private truckType style;
    private int weight;

    public RentalTruck(int rentalID, String currentRental, int numOfPassengers) {
        super(rentalID, currentRental, numOfPassengers);
    }
}
