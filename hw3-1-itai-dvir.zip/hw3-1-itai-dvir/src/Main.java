public class Main {
    public static void main(String[] args) {
        Employee [] emps = new Employee[10];
        for (Employee emp: emps) {
            emp.Salary();
        }

    }
}
