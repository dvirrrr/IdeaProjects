public class Manager extends Employee {
    protected double monthlySalary;
    public double Salary() {
        return monthlySalary;
    }
}
