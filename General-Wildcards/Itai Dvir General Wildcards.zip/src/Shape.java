public abstract class Shape {

    public abstract double cal_area();
    public abstract double cal_permieter();

}
