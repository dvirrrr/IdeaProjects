public class MP4 extends MP3 {
    private int screen_length;

    public MP4(String manufacturer, String edition) {
        super(manufacturer, edition);
    }
}
