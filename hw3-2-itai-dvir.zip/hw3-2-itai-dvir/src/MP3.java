public class MP3 extends Product {
    private boolean radio;
    private boolean speaker;

    public MP3(String manufacturer, String edition) {
        super(manufacturer, edition);
    }
}
