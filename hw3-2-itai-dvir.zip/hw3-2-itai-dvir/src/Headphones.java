public class Headphones extends Product {
    private double range;

    public Headphones(String beats, String limited) {
        super();
    }
}
