interface ExpressionElement {
    double evaluate();
    String toString();
}
