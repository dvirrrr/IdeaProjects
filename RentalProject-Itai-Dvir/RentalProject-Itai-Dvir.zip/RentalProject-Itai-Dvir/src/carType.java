public enum carType {
    Hatchback,
    Sedan,
    Compact
}
