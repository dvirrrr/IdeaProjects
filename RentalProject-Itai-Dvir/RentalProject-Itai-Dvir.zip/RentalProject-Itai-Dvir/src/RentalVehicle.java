public abstract class RentalVehicle {
    private int rentalID;
    private String currentRental;
    private int numOfPassengers;

    public RentalVehicle(int rentalID, String currentRental, int numOfPassengers) {
        this.rentalID = rentalID;
        this.currentRental = currentRental;
        this.numOfPassengers = numOfPassengers;
    }
    public void StartEngine() {
        System.out.println("Turn key to ignition setting");
        System.out.println("Turn key to on");
    }
    public void stopEngine() {
        System.out.println("Turn key to off");
    }

    public static void printRentals(RentalVehicle [] r) {
        for (int i = 0; i < r.length; i++) {
            if (r[i] == null) { continue; }
            System.out.println(r[i].toString());
        }
    }

    public static void printLandRentals(RentalVehicle [] r) {
        for (int i = 0; i < r.length; i++) {
            if (r[i] == null) { continue; }
            if(r[i] instanceof RentalCar || r[i] instanceof RentalTruck) {
            System.out.println(r[i].toString());
            }
        }
    }

    @Override
    public String toString() {
        return "rentalID: " + rentalID + '\n' +
                "currentRental:" + currentRental + '\n' +
                "numOfPassengers:" + numOfPassengers+ '\n';
    }
}
